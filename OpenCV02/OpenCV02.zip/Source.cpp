#include <iostream>
#include <opencv2/opencv.hpp>

void HistogramEquslization(const cv::Mat& in_image, cv::Mat& out_image, cv::Mat& in_histogram, cv::Mat& out_histogram) {
	const int histogram_size = 256;
	int histogram[histogram_size];
	int histogram_o[histogram_size];
	int histogram_c[histogram_size];

	int hist_w = 512, hist_h = 400;
	int bin_w = cvRound(static_cast<double>(hist_w / histogram_size));
	int max_in_hist = 0;
	int max_out_hist = 0;
	for (int i = 0; i < histogram_size; ++i) {
		histogram[i] = 0;
		histogram_c[i] = 0;
		histogram_o[i] = 0;
	}

	for (int i = 0; i < in_image.cols * in_image.rows; ++i) {
		int value = in_image.data[i];
		histogram[value]++;
		max_in_hist = std::max(max_in_hist, histogram[value]);
	}
	histogram_c[0] = histogram[0];
	for (int i = 1; i < histogram_size; ++i) {
		histogram_c[i] = histogram_c[i - 1] + histogram[i];
	}

	double alpha = 255.0 / static_cast<double>(in_image.rows * in_image.cols);
	for (int i = 0; i < in_image.rows * in_image.cols; ++i) {
		int value = in_image.data[i];
		out_image.data[i] = histogram_c[value] * alpha;

		int new_value = out_image.data[i];
		histogram_o[new_value]++;

		max_out_hist = std::max(max_out_hist, histogram_o[new_value]);
	}
	for (int i = 0; i < histogram_size; ++i) {
		double in_value = static_cast<double>(histogram[i]) / static_cast<double>(max_in_hist);
		double out_value = static_cast<double>(histogram_o[i]) / static_cast<double>(max_out_hist);
		cv::line(in_histogram,  cv::Point(bin_w * (i), hist_h),
								cv::Point(bin_w * (i), hist_h - cvRound(hist_h * in_value)), 
								cv::Scalar(255, 0, 0), 2, 8, 0);
		cv::line(out_histogram, cv::Point(bin_w * (i), hist_h),
								cv::Point(bin_w * (i), hist_h - cvRound(hist_h * out_value)),
								cv::Scalar(255, 0, 0), 2, 8, 0);
	}
}

int main(int argc, char* argv[]) {
	std::string image_path = "C:/Users/dmitr/source/repos/OpenCV02/images/einstein.jpg";
	cv::Mat image;
	if (argc > 1)
		image = cv::imread(argv[1], cv::IMREAD_GRAYSCALE);
	else
		image = cv::imread(image_path, cv::IMREAD_GRAYSCALE);
	if (image.empty())
		std::cout << "Failed to load the image.";
	else {
		cv::Mat hist_image = cv::Mat::zeros(image.size(), image.type());
		cv::Mat inHistImage(400, 512, CV_8UC3, cv::Scalar(0, 0, 0));
		cv::Mat outHistImage(400, 512, CV_8UC3, cv::Scalar(0, 0, 0));

		HistogramEquslization(image, hist_image, inHistImage, outHistImage);
		cv::namedWindow("Original image", cv::WINDOW_AUTOSIZE);
		cv::namedWindow("Equalized image", cv::WINDOW_AUTOSIZE);
		
		cv::imshow("Original image", image);
		cv::imshow("Equalized image", hist_image);
		cv::imshow("In_histogram", inHistImage);
		cv::imshow("Out_histogram", outHistImage);
		cv::waitKey(0);
	}
}