#include "ImageProcessing.h"
#include <algorithm>

double** ImageProcessing::SobelOperator(const cv::Mat& in_image, cv::Mat& out_image) {
	double* g_y = new double[9] {1, 2, 1, 0, 0, 0, -1, -2, -1};
	double* g_x = new double[9] {-1, 0, 1, -2, 0, 2, -1, 0, 1 };
	double** g_d = new double*[in_image.rows];
	for (int i = 0; i < in_image.rows; ++i)
		g_d[i] = new double[in_image.cols];

	cv::Mat y_image(in_image.size(), in_image.type());
	cv::Mat x_image(in_image.size(), in_image.type());

	convolution(in_image, y_image, g_y, 3, 1.0);
	convolution(in_image, x_image, g_x, 3, 1.0);
	//cv::imshow("y image", y_image);
	//cv::imshow("x image", x_image);

	double g_max = 0;
	for (int i = 0; i < out_image.rows; ++i) {
		for (int j = 0; j < out_image.cols; ++j) {
			double g_y_val = y_image.data[i * in_image.cols + j];
			double g_x_val = x_image.data[i * in_image.cols + j];

			double g = sqrt(g_y_val * g_y_val + g_x_val * g_x_val);
			g = shrink(g, 0, 255);
			g_max = std::max(g, g_max);
			if (g_x_val == 0)
				g_d[i][j] = PI / 2;
			else
				g_d[i][j] = atan2(g_y_val, g_x_val);
		}
	}
	for (int i = 0; i < out_image.rows; ++i) {
		for (int j = 0; j < out_image.cols; ++j) {
			double g_y_val = y_image.data[i * in_image.cols + j];
			double g_x_val = x_image.data[i * in_image.cols + j];

			double g = sqrt(g_y_val * g_y_val + g_x_val * g_x_val);

			out_image.data[i * out_image.cols + j] = (g / g_max) * 255;
		}
	}
	return g_d;
}

double** ImageProcessing::ScharrOperator(const cv::Mat& in_image, cv::Mat& out_image)
{
	int height = in_image.rows;
	int width = in_image.cols;

	double* g_y = new double[9]{ 47, 162, 47, 0, 0, 0, -47, -162, -47 };
	double* g_x = new double[9]{ -47, 0, 47, -162, 0, 162, -47, 0, 47 };
	double** g_d = new double* [in_image.rows];
	for (int i = 0; i < in_image.rows; ++i)
		g_d[i] = new double[in_image.cols];

	double** y_image = new double* [height];
	for (int i = 0; i < height; ++i)
		y_image[i] = new double[width];
	double** x_image = new double*[height];
	for (int i = 0; i < height; ++i)
		x_image[i] = new double[width];

	convolution(in_image, y_image, g_y, 3, 1.0 / 250.0);
	convolution(in_image, x_image, g_x, 3, 1.0 / 250.0);
	//cv::imshow("y image", y_image);
	//cv::imshow("x image", x_image);

	double g_max = 0;
	for (int i = 0; i < out_image.rows; ++i) {
		for (int j = 0; j < out_image.cols; ++j) {
			double g_y_val = y_image[i][j];
			double g_x_val = x_image[i][j];

			double g = sqrt(g_y_val * g_y_val + g_x_val * g_x_val);
			g = shrink(g, 0, 255);
			g_max = std::max(g, g_max);
			g_d[i][j] = atan2(g_y_val, g_x_val);
		}
	}
	for (int i = 0; i < out_image.rows; ++i) {
		for (int j = 0; j < out_image.cols; ++j) {
			double g_y_val = y_image[i][j];
			double g_x_val = x_image[i][j];

			double g = sqrt(g_y_val * g_y_val + g_x_val * g_x_val);

			out_image.data[i * out_image.cols + j] = (g / g_max) * 255;
		}
	}
	return g_d;
}


void ImageProcessing::LaplaceOperator(const cv::Mat& in_image, cv::Mat& out_image)
{
	double mask[9] = { 0, 1, 0, 1, -4, 1, 0, 1, 0 };
	double** result = new double* [in_image.rows];
	for (int i = 0; i < in_image.rows; ++i)
		result[i] = new double[in_image.cols];
	convolution(in_image, result, mask, 3, 1.0/8.0);
	for (int i = 0; i < in_image.rows; ++i) {
		for (int j = 0; j < in_image.cols; ++j) {
			out_image.data[i * in_image.cols + j] = abs(result[i][j]);
		}
	}
}

void ImageProcessing::apply(const cv::Mat& in_image, cv::Mat& applied_image, cv::Mat& out_image)
{
	assert(in_image.size() == applied_image.size());
	for (int i = 0; i < in_image.rows; ++i) {
		for (int j = 0; j < in_image.cols; ++j) {
			out_image.data[i * in_image.cols + j] = in_image.data[i * in_image.cols + j] + applied_image.data[i * in_image.cols + j];
		}
	}
}
