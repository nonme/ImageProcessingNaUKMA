#include "ImageProcessing.h"

void ImageProcessing::findBorder(const cv::Mat& in_image, cv::Mat& out_image) {
	for (int i = 0; i < out_image.rows; ++i) {
		for (int j = 0; j < out_image.cols; ++j) {
			if (in_image.data[i * in_image.cols + j] == 255 && !(in_image.data[(i - 1) * in_image.cols + j - 1] & 
				in_image.data[(i - 1) * in_image.cols + j] & in_image.data[(i - 1) * in_image.cols + j + 1] &
				in_image.data[i * in_image.cols + j - 1] & in_image.data[i * in_image.cols + j] & in_image.data[i * in_image.cols + j + 1]
				& in_image.data[(i + 1) * in_image.cols + j - 1] & in_image.data[(i + 1) * in_image.cols + j] 
				& in_image.data[(i + 1) * in_image.cols + j + 1])) {
				out_image.data[i * out_image.cols + j] = 255;
			}
			else {
				out_image.data[i * out_image.cols + j] = 0;
			}
		}
	}
}
